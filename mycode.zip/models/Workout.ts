interface IExercise {
    name: string;
    favorite: boolean;
    muscleGroup: string[];
    sets: number;
    reps: number;
    weight: number;
};

// Define the workout object type
export interface IWorkout {
    name: string;
    time: Date || null; // You can use a specific type for time if needed
    color: string;
    timesCompleted: number;
    date: string; // You can use a specific type for date if needed
    exercises: Exercise[];
};